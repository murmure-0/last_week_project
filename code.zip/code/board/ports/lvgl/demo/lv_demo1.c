/*
 * @Author: murnure 2662761173@qq.com
 * @Date: 2024-07-29 16:00:39
 * @LastEditors: murnure 2662761173@qq.com
 * @LastEditTime: 2024-07-31 00:07:59
 * @FilePath: \code\board\ports\lvgl\demo\lv_demo.c
 * @Description: 
 * 
 * Copyright (c) 2024 by murmure, All Rights Reserved. 
 */
/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author        Notes
 * 2021-10-17     Meco Man      first version
 * 2022-05-10     Meco Man      improve rt-thread initialization process
 */
// #include <lvgl.h>

// void lv_user_gui_init(void)
// {
    /* display demo; you may replace with your LVGL application at here */
//    extern void lv_demo_pingpong(void);
//    extern lv_demo_calendar();
//    lv_demo_calendar();


//    extern void lv_demo_music(void);
//    lv_demo_music();


    // extern void lv_demo_benchmark(void);
    // lv_demo_benchmark();

//    extern lv_demo_widgets();
//    lv_demo_widgets();
// }
