/*
 * @Author: murnure 2662761173@qq.com
 * @Date: 2024-07-29 16:00:39
 * @LastEditors: murnure 2662761173@qq.com
 * @LastEditTime: 2024-07-30 23:58:51
 * @FilePath: \code\board\ports\lvgl\lv_port_indev.c
 * @Description: 
 * 
 * Copyright (c) 2024 by murmure, All Rights Reserved. 
 */
/*
 * Copyright (c) 2006-2022, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-10-18     Meco Man     The first version
 */
#include <lvgl.h>
#include <stdbool.h>
#include <rtdevice.h>
#include <board.h>

// void lv_port_indev_init(void)
// {

// }
